package com.mycompany.smartstudyassistant;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import javax.swing.Timer;

/**
 *
 * @author Areeba Malik
 */
public class SmartStudyAssistant {
    public static void main(String[] args) {

    try {
    for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
            UIManager.setLookAndFeel(info.getClassName());
            break;
        }
    }
} catch (Exception e) {
    
    try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); } 
    catch (Exception ex) {} 
}
Color customBaseColor = new Color(213, 195, 176);
UIManager.put("ScrollBar.thumb", customBaseColor.darker()); 
UIManager.put("ScrollBar.track", customBaseColor);      
     //MAIN FRAME
        JFrame mainframe = new JFrame("SPSA"); 
        mainframe.setSize(800,800);
        mainframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        mainframe.setLayout(null); 
        mainframe.setLocationRelativeTo(null); 
        //MAIN FRAME BACKGROUND IMAGE
        ImageIcon bgImage = new ImageIcon("src/main/resources/images/frame.JPG");
        JLabel background = new JLabel() { 
            public void paintComponent(Graphics g) {
                g.drawImage(bgImage.getImage(), 0, 0, getWidth(), getHeight(), this);
            }
        };
        background.setBounds(0, 0, 800, 800); 
        background.setLayout(null);
        mainframe.setContentPane(background);
    //MAINFRAME TEXT
    //UPPER TEXT
    JLabel LABEL1 = new JLabel("Smart Personal Study Assistant");
    LABEL1.setFont(new Font("Segoe UI", Font.BOLD, 35));
    LABEL1.setForeground(new Color(30, 30, 60));
    LABEL1.setBounds(143, 40, 800, 150);
    //LOWER TEXT
    JLabel LABEL2 = new JLabel("Smart Personal Study Assistant");
    LABEL2.setFont(new Font("Segoe UI", Font.BOLD, 35));
    LABEL2.setForeground(Color.LIGHT_GRAY);
    LABEL2.setBounds(140, 38, 800, 150);
///////////////////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    // PLANNER BUTTON
    Image img = new ImageIcon("src/main/resources/images/planner.png").getImage();
    Image scaled = img.getScaledInstance(30, 33, Image.SCALE_AREA_AVERAGING);
    JButton btnPlanner = new JButton("Planner", new ImageIcon(scaled));

    btnPlanner.setBounds(160, 190, 180, 40);
    btnPlanner.setFont(new Font("Arial", Font.BOLD, 16));
    btnPlanner.setFocusable(false);
    btnPlanner.setBorderPainted(false);
    //NOTES BUTTON
    ImageIcon iconNN = new ImageIcon("src/main/resources/images/notes.png");
    Image imgN = iconNN.getImage().getScaledInstance(30, 30, Image.SCALE_AREA_AVERAGING);
    JButton btnNotes = new JButton("Notes", new ImageIcon(imgN));
    btnNotes.setBounds(450, 190, 180, 40);
    btnNotes.setFont(new Font("Arial", Font.BOLD, 16));
    btnNotes.setFocusable(false);
    btnNotes.setBorderPainted(false);
    //TIMER BUTTON
    ImageIcon iconTT = new ImageIcon("src/main/resources/images/timer.png");
    Image imgT = iconTT.getImage().getScaledInstance(30, 29, Image.SCALE_AREA_AVERAGING);
    JButton btnTimer = new JButton("Timer", new ImageIcon(imgT));
    btnTimer.setBounds(160, 270, 180, 40);
    btnTimer.setFont(new Font("Arial", Font.BOLD, 16));
    btnTimer.setFocusable(false);
    btnTimer.setBorderPainted(false);
    //TRACKER BUTTON
    ImageIcon icontt = new ImageIcon("src/main/resources/images/tracker.png");
    Image imgt = icontt.getImage().getScaledInstance(24, 35, Image.SCALE_AREA_AVERAGING);
    JButton btnTracker = new JButton("Tracker", new ImageIcon(imgt));
    btnTracker.setBounds(450, 270, 180, 40);
    btnTracker.setFont(new Font("Arial", Font.BOLD, 16));
    btnTracker.setFocusable(false);
    btnTracker.setBorderPainted(false);
    //TODO BUTTON
    ImageIcon icontdd = new ImageIcon("src/main/resources/images/todo.png");
    Image imgtd = icontdd.getImage().getScaledInstance(24, 24, Image.SCALE_AREA_AVERAGING);
    JButton btnTodo = new JButton("To-Do List", new ImageIcon(imgtd));
    btnTodo.setBounds(160, 350, 180, 40);
    btnTodo.setFont(new Font("Arial", Font.BOLD, 15));
    btnTodo.setFocusable(false);
    btnTodo.setBorderPainted(false);
    //EXPORT BUTTON
    ImageIcon iconE = new ImageIcon("src/main/resources/images/export.png");
    Image imgE = iconE.getImage().getScaledInstance(24, 24, Image.SCALE_AREA_AVERAGING);
    JButton btnExport = new JButton("Export", new ImageIcon(imgE));
    btnExport.setBounds(450, 350, 180, 40);
    btnExport.setFont(new Font("Arial", Font.BOLD, 15));
    btnExport.setFocusable(false);
    btnExport.setBorderPainted(false);
    //LOAD BUTTON
    ImageIcon iconL = new ImageIcon("src/main/resources/images/load.png");
    Image imgL = iconL.getImage().getScaledInstance(24, 24, Image.SCALE_AREA_AVERAGING);
    JButton btnLoad = new JButton("Load Data", new ImageIcon(imgL));
    btnLoad.setBounds(160, 430, 180, 40);
    btnLoad.setFont(new Font("Arial", Font.BOLD, 15));
    btnLoad.setFocusable(false);
    btnLoad.setBorderPainted(false);
    //EXIT BUTTON
    ImageIcon iconEx = new ImageIcon("src/main/resources/images/exit.png");
    Image imgEx = iconEx.getImage().getScaledInstance(24, 24, Image.SCALE_AREA_AVERAGING);
    JButton btnExit = new JButton("Exit", new ImageIcon(imgEx));
    btnExit.setBounds(450, 430, 180, 40);
    btnExit.setFont(new Font("Arial", Font.BOLD, 15));
    btnExit.setFocusable(false);
    btnExit.setBorderPainted(false);
    mainframe.add(LABEL1);
    mainframe.add(LABEL2);
    mainframe.add(btnPlanner);
    mainframe.add(btnNotes);
    mainframe.add(btnTimer);
    mainframe.add(btnTracker);
    mainframe.add(btnTodo);
    mainframe.add(btnExport);
    mainframe.add(btnLoad);
    mainframe.add(btnExit);
    mainframe.setVisible(true);
///////////////////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    //PLANNER
 btnPlanner.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        //PLANNER FRAME
        JFrame plannerframe = new JFrame("Planner"); 
        plannerframe.setSize(800, 800); 
        plannerframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        plannerframe.setLayout(null); 
        plannerframe.setLocationRelativeTo(null);
        //PLANNER FRAME BACKGROUND IMAGE
        ImageIcon bgImage = new ImageIcon("src/main/resources/images/frame.JPG");
        JLabel 
        background = new JLabel() { 
            public void paintComponent(Graphics g) {
                g.drawImage(bgImage.getImage(), 0, 0, getWidth(), getHeight(), this);
            }
        };
        background.setBounds(0, 0, 800, 800); 
        background.setLayout(null);
        plannerframe.setContentPane(background);
        //PLANNER TEXT
        JLabel LABEL1 = new JLabel("Planner");
        LABEL1.setFont(new Font("Segoe UI", Font.BOLD, 35));
        LABEL1.setForeground(new Color(30, 30, 60));
        LABEL1.setBounds(308, 40, 300, 50); 
        JLabel LABEL2 = new JLabel("Planner");
        LABEL2.setFont(new Font("Segoe UI", Font.BOLD, 35));
        LABEL2.setForeground(Color.LIGHT_GRAY);  
        LABEL2.setBounds(305, 38, 300, 50); 
        //COMBO BOX
        //SELECT DATE LABEL
        JLabel DateLabel = new JLabel("Select Date: ");
        DateLabel.setBounds(50, 120, 150, 25); 
        DateLabel.setFont(new Font("Segoe UI", Font.BOLD, 25));
        //Date ComboBox
        String[]Date = {"Select Date","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
        JComboBox<String> date = new JComboBox<>(Date);
        date.setBounds(210, 120, 120, 28);
        date.setFocusable(false);
        //Month ComboBox
        String[] Months = {"Select Month","January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December"};
        JComboBox<String> month = new JComboBox<>(Months);
        month.setBounds(350, 120, 120, 28); 
        month.setFocusable(false);
        //Year ComboBox
        String[] Years = {"Select year","2025", "2026", "2027", "2028","2029","2030","2031","2032","2033","2034","2035"};
        JComboBox<String> year = new JComboBox<>(Years);
        year.setBounds(490, 120, 120, 28); 
        year.setFocusable(false);
        //Check date month year   
        ActionListener Update = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedMonth = month.getSelectedIndex();
                String yearStr = (String) year.getSelectedItem();

                if (selectedMonth <= 0 || yearStr == null || yearStr.equals("Select year")) return;
                int selectedYear = Integer.parseInt(yearStr);
                //LOGIC
                int days;
                if (selectedMonth == 2) {
                    days = (selectedYear % 4 == 0 && (selectedYear % 100 != 0 || selectedYear % 400 == 0)) ?
                    29 : 28;
                } 
                else if (selectedMonth == 4 || selectedMonth == 6 || selectedMonth == 9 || selectedMonth == 11) {
                    days = 30;
                } 
                else {
                    days = 31;
                }
                date.removeAllItems();
                for (int i = 1; i <= days; i++) {
                    date.addItem(String.valueOf(i));
                }
            }
        };
        month.addActionListener(Update);
        year.addActionListener(Update);
        Update.actionPerformed(null); // to initialize Day Combobox once
  
        //TASK + PLANNED TASKS LABEL
        JLabel TaskLabel = new JLabel("Add Study Task:");
        TaskLabel.setBounds(50, 180, 200, 30); 
        TaskLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        JLabel PlannedLabel = new JLabel("Planned Tasks:");
        PlannedLabel.setBounds(50, 270, 200, 25); 
        PlannedLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        JTextField TaskField = new JTextField();
        TaskField.setBounds(50, 215, 300, 30); 
        //JLIST
        DefaultListModel<String> List_data = new DefaultListModel<>();
        JList Task = new JList(List_data);
        JScrollPane scroll = new JScrollPane(Task);
        scroll.setBounds(50, 305, 520, 250); 
        //ADD BUTTON
        ImageIcon iconA = new ImageIcon("src/main/resources/images/add.png");
        Image imgA = iconA.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
        ImageIcon iconAA = new ImageIcon(imgA);
        JButton AddButton = new JButton("Add Task",iconAA);
        AddButton.setBounds(370, 215, 120, 30); 
        AddButton.setFont(new Font("Arial", Font.BOLD, 12)); 
        AddButton.setFocusable(false);
        AddButton.setBorderPainted(false);
        //ADD BUTTON ACTION LISTENER
        AddButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                String task = TaskField.getText();
                List_data.addElement(task);
                TaskField.setText("");      
                //to save data 
                try (FileWriter writer = new FileWriter("StudyData/planner.txt")) {
                    for (int 
                    i = 0; i < List_data.size(); i++) { 
                        writer.write(List_data.getElementAt(i) + "\n");
                    }
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(plannerframe, "Error saving planner data.");
                }
            }
        });
        //REMOVE TASK BUTTON
        ImageIcon iconR = new ImageIcon("src/main/resources/images/remove.png");
        Image imgR = iconR.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
        ImageIcon iconRR = new ImageIcon(imgR);
        JButton RemoveButton = new JButton("Remove",iconRR);
        RemoveButton.setBounds(500, 215, 120, 30); 
        RemoveButton.setFont(new Font("Arial", Font.BOLD, 12)); 
        RemoveButton.setFocusable(false);
        RemoveButton.setBorderPainted(false);
        //REMOVE BUTTON ACTION LISTENER
        RemoveButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
               int index = Task.getSelectedIndex();
              if (index != -1) {
                List_data.remove(index);
                } 
              else {
                javax.swing.JOptionPane.showMessageDialog(plannerframe,"No item selected.");
                System.out.println("");
            }
           }
        });
        //BACK BUTTON
        ImageIcon iconB = new ImageIcon("src/main/resources/images/back.png");
        Image imgB = iconB.getImage().getScaledInstance(23, 23, Image.SCALE_SMOOTH);
        ImageIcon iconBB = new ImageIcon(imgB);
        JButton BackButton = new JButton("Back",iconBB);
        BackButton.setBounds(600, 700, 160, 40); 
        BackButton.setFont(new Font("Arial", Font.BOLD, 16)); 
        BackButton.setFocusable(false);
        BackButton.setBorderPainted(false);
        //BACK BUTTON ACTION LISTENER
        BackButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainframe.setVisible(true); 
                plannerframe.dispose();      
            }
        });
        plannerframe.add(LABEL1);
        plannerframe.add(LABEL2);
        plannerframe.add(DateLabel);
        plannerframe.add(date);
        plannerframe.add(month);
        plannerframe.add(year);
        plannerframe.add(TaskLabel);
        plannerframe.add(PlannedLabel);
        plannerframe.add(TaskField);
        plannerframe.add(scroll);
        plannerframe.add(AddButton);
        plannerframe.add(RemoveButton);       
        plannerframe.add(BackButton);
        plannerframe.setVisible(true);   
        mainframe.setVisible(false);
    }
 });
///////////////////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        //NOTES
     btnNotes.addActionListener(new ActionListener() {
     public void actionPerformed(ActionEvent e) {
        //NOTES FRAME
        JFrame notesframe = new JFrame("Notes"); 
        notesframe.setSize(800, 800); 
        notesframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        notesframe.setLayout(null); 
        notesframe.setLocationRelativeTo(null);
        //NOTES FRAME BACKGROUND IMAGE
        ImageIcon bgImage = new ImageIcon("src/main/resources/images/frame.JPG");
        JLabel background = new JLabel() { 
            public void paintComponent(Graphics g) {
                g.drawImage(bgImage.getImage(), 0, 0, getWidth(), getHeight(), this);
            }
        };
        background.setBounds(0, 0, 800, 800);
        background.setLayout(null);
        notesframe.setContentPane(background);
        //NOTES TEXT
        JLabel LABEL1 = new JLabel("Notes");
        LABEL1.setFont(new Font("Segoe UI", Font.BOLD, 35));
        LABEL1.setForeground(new Color(30, 30, 60));
        LABEL1.setBounds(350, 40, 300, 50); 
        JLabel LABEL2 = new JLabel("Notes");
        LABEL2.setFont(new Font("Segoe UI", Font.BOLD, 35));
        LABEL2.setForeground(Color.LIGHT_GRAY);
        LABEL2.setBounds(348, 38, 300, 50); 
        //TEXT AREA
        JTextArea textArea = new JTextArea();
        JScrollPane scroll = new JScrollPane(textArea);
        scroll.setBounds(50, 120, 690, 300);
        //CLEAR BUTTON
        ImageIcon iconC = new ImageIcon("src/main/resources/images/remove.png");
        Image imgC = iconC.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
        ImageIcon iconCC = new ImageIcon(imgC);
        JButton ClearButton = new JButton("Clear",iconCC);
        ClearButton.setBounds(135, 450, 150, 35);
        ClearButton.setFont(new Font("Arial", Font.BOLD, 12)); 
        ClearButton.setFocusable(false);
        ClearButton.setBorderPainted(false);
        //CLEAR BUTTON ACTION LISTENER
        ClearButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textArea.setText("");
            }
        });
        //SAVE BUTTON
        ImageIcon iconS = new ImageIcon("src/main/resources/images/save.png");
        Image imgS = iconS.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
        ImageIcon iconSS = new ImageIcon(imgS);
        JButton SaveButton = new JButton("Save",iconSS);
        SaveButton.setBounds(315, 450, 150, 35); 
        SaveButton.setFont(new Font("Arial", Font.BOLD, 12)); 
        SaveButton.setFocusable(false);
        SaveButton.setBorderPainted(false);
        //SAVE BUTTON ACTION LISTENER
        SaveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try (FileWriter writer = new FileWriter("StudyData/notes.txt")) {
                    writer.write(textArea.getText());
               
                    JOptionPane.showMessageDialog(notesframe, "Note saved successfully!");
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(notesframe, "Error saving note.");
                }
            }
        });
        //SHOW BUTTON
        ImageIcon icons = new ImageIcon("src/main/resources/images/show.png");
        Image imgs = icons.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
        ImageIcon iconss = new ImageIcon(imgs);
        JButton ShowButton = new JButton("Show",iconss);
        ShowButton.setBounds(495, 450, 150, 35); 
        ShowButton.setFont(new Font("Arial", Font.BOLD, 12)); 
        ShowButton.setFocusable(false);
        ShowButton.setBorderPainted(false);
        //SHOW BUTTON ACTION LISTENER
        ShowButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try (BufferedReader reader = new BufferedReader(new FileReader("note.txt"))) {
                    textArea.read(reader, null);
             
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(notesframe, "No saved note found.");
                }
            }
        });
        //BACK BUTTON
        ImageIcon iconB = new ImageIcon("src/main/resources/images/back.png");
        Image imgB = iconB.getImage().getScaledInstance(23, 23, Image.SCALE_SMOOTH);
        ImageIcon iconBB = new ImageIcon(imgB);
        JButton BackButton = new JButton("Back",iconBB);
        BackButton.setBounds(600, 700, 160, 40); 
        BackButton.setFont(new Font("Arial", Font.BOLD, 16)); 
        BackButton.setFocusable(false);
        BackButton.setBorderPainted(false);
        //BACK BUTTON ACTION LISTENER
        BackButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainframe.setVisible(true); 
                notesframe.dispose();      
            }
        });
        notesframe.add(LABEL1);
        notesframe.add(LABEL2);
        notesframe.add(scroll);
        notesframe.add(ClearButton);
        notesframe.add(SaveButton);
        notesframe.add(ShowButton);
        notesframe.add(BackButton);
        notesframe.setVisible(true);
        mainframe.setVisible(false);
    }
  });
///////////////////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        //TIMER
        btnTimer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame timerframe = new JFrame("Timer"); 
                timerframe.setSize(800, 800);
                timerframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
                timerframe.setLayout(null); 
                timerframe.setLocationRelativeTo(null);
                //TIMER FRAME BACKGROUND IMAGE
                ImageIcon bgImage = new ImageIcon("src/main/resources/images/frame.JPG");
                JLabel background = new JLabel() { 
                    public void paintComponent(Graphics g) {
                        g.drawImage(bgImage.getImage(), 0, 0, getWidth(), getHeight(), this);
                    }
                };
                background.setBounds(0, 0, 800, 800); 
                background.setLayout(null);
                timerframe.setContentPane(background);
                //TIMER TEXT
                JLabel LABEL1 = new JLabel("Timer");
                LABEL1.setFont(new Font("Segoe UI", Font.BOLD, 35));
                LABEL1.setForeground(new Color(30, 30, 60));
                LABEL1.setBounds(340, 40, 300, 50); 
                JLabel LABEL2 = new JLabel("Timer");
                LABEL2.setFont(new Font("Segoe UI", Font.BOLD, 35));
                LABEL2.setForeground(Color.LIGHT_GRAY);  
                LABEL2.setBounds(338, 38, 300, 50);
                //LABEL
                JLabel TimeLabel = new JLabel("00:00:00");
                TimeLabel.setFont(new Font("Segoe UI", Font.BOLD, 100));
                TimeLabel.setBounds(190, 180, 500, 100); 
                //TIMER LOGIC
                final int[] seconds = { 0 };
                final Timer[] swingTimer = { null }; 
                swingTimer[0] = new Timer(1000, new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        seconds[0]++;
                        int hrs = seconds[0] / 3600;
                        int mins = (seconds[0] % 3600) / 60;
                        int secs = seconds[0] % 60;

                        String timeStr = String.format("%02d:%02d:%02d", hrs, mins, secs);
                        TimeLabel.setText(timeStr); 
                    }
                });
                //START BUTTON
                ImageIcon iconS = new ImageIcon("src/main/resources/images/start.png");
                Image imgS = iconS.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
                ImageIcon iconSS = new ImageIcon(imgS);
                JButton StartButton = new JButton("Start",iconSS);
                StartButton.setBounds(140, 400, 150, 40); 
                StartButton.setFont(new Font("Arial", Font.BOLD, 16)); 
                StartButton.setFocusable(false);
                StartButton.setBorderPainted(false);
                // START BUTTON ACTION
                StartButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        swingTimer[0].start();
                    }
                });
                //PAUSE BUTTON
                ImageIcon iconP = new ImageIcon("src/main/resources/images/pause.png");
                Image imgP = iconP.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
                ImageIcon iconPP = new ImageIcon(imgP);
                JButton PauseButton = new JButton("Pause",iconPP);
                PauseButton.setBounds(320, 400, 150, 40); 
                PauseButton.setFont(new Font("Arial", Font.BOLD, 16)); 
                PauseButton.setFocusable(false);
                PauseButton.setBorderPainted(false);
                //PAUSE BUTTON ACTION
                PauseButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        swingTimer[0].stop();
                    }
                });
                //RESET BUTTON
                ImageIcon iconR = new ImageIcon("src/main/resources/images/reset.png");
                Image imgR = iconR.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
                ImageIcon iconRR = new ImageIcon(imgR);
                JButton ResetButton = new JButton("Reset",iconRR);
                ResetButton.setBounds(500, 400, 150, 40); 
                ResetButton.setFont(new Font("Arial", Font.BOLD, 16)); 
                ResetButton.setFocusable(false);
                ResetButton.setBorderPainted(false);
                //RESET BUTTON ACTION
                ResetButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        swingTimer[0].stop();
                        seconds[0] = 0;
                        TimeLabel.setText("00:00:00");
                    }
                });
                //BACK BUTTON
                ImageIcon iconB = new ImageIcon("src/main/resources/images/back.png");
                Image imgB = iconB.getImage().getScaledInstance(23, 23, Image.SCALE_SMOOTH);
                ImageIcon iconBB = new ImageIcon(imgB);
                JButton BackButton = new JButton("Back",iconBB);
                BackButton.setBounds(600, 700, 160, 40); 
                BackButton.setFont(new Font("Arial", Font.BOLD, 16)); 
                BackButton.setFocusable(false);
                BackButton.setBorderPainted(false);
                //BACK BUTTON ACTION LISTENER
                BackButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        mainframe.setVisible(true); 
                        timerframe.dispose();      
                    }
                });
                timerframe.add(LABEL1);
                timerframe.add(LABEL2);
                timerframe.add(TimeLabel);
                timerframe.add(StartButton);
                timerframe.add(PauseButton);
                timerframe.add(ResetButton);
                timerframe.add(BackButton);
                timerframe.setVisible(true);
                mainframe.setVisible(false);
            }
        });
///////////////////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        //TRACKER 
        btnTracker.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame trackerframe = new JFrame("Tracker"); 
                trackerframe.setSize(800, 800);
                trackerframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
                trackerframe.setLayout(null); 
                trackerframe.setLocationRelativeTo(null);
                //TRACKER FRAME BACKGROUND IMAGE
                ImageIcon bgImage = new ImageIcon("src/main/resources/images/frame.JPG");
                JLabel background = new JLabel() { 
                    public void paintComponent(Graphics g) {
                        g.drawImage(bgImage.getImage(), 0, 0, getWidth(), getHeight(), this);
                    }
                };
                background.setBounds(0, 
                0, 800, 800); 
                background.setLayout(null);
                trackerframe.setContentPane(background);
                //TRACKER TEXT
                JLabel LABEL1 = new JLabel("Tracker");
                LABEL1.setFont(new Font("Segoe UI", Font.BOLD, 35));
                LABEL1.setForeground(new Color(30, 30, 60));
                LABEL1.setBounds(335, 40, 300, 50); 
                JLabel LABEL2 = new JLabel("Tracker");
                LABEL2.setFont(new Font("Segoe UI", Font.BOLD, 35));
                LABEL2.setForeground(Color.LIGHT_GRAY);  
                LABEL2.setBounds(332, 38, 300, 50); 
                // LABELS
                JLabel DateLabel = new JLabel("Date (dd-mm-yyyy): ");
                DateLabel.setBounds(50, 150, 250, 25); 
                DateLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
                JLabel SubjectLabel = new JLabel("Subject: "); 
                SubjectLabel.setBounds(50, 200, 250, 25); 
                SubjectLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
                JLabel DurationLabel = new JLabel("Duration (mins): ");
                DurationLabel.setBounds(50, 250, 250, 25); 
                DurationLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));    
                //Text Fields
                JTextField DateField = new JTextField();
                DateField.setBounds(300, 150, 300, 28); 
                JTextField SubjectField = new JTextField();
                SubjectField.setBounds(300, 200, 300, 28); 
                JTextField DurationField = new JTextField();
                DurationField.setBounds(300, 250, 300, 28); 
                //TEXT AREA
                JTextArea DisplayArea = new JTextArea();
                DisplayArea.setBounds(43, 400, 700, 200); 
                //SAVE BUTTON
                ImageIcon iconS = new ImageIcon("src/main/resources/images/save.png");
                Image imgS = iconS.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
                ImageIcon iconSS = new ImageIcon(imgS);
                JButton SaveButton = new JButton("Save",iconSS);
                SaveButton.setBounds(225, 320, 150, 30); 
                SaveButton.setFont(new Font("Arial", Font.BOLD, 12)); 
                SaveButton.setFocusable(false);
                SaveButton.setBorderPainted(false);
                //SAVE BUTTON ACTION LISTENER 
                ArrayList<String> studyData = new ArrayList<>();
                SaveButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        String date     = DateField.getText().trim();
                        String subject  = SubjectField.getText().trim();
                        String duration = DurationField.getText().trim();
                        if (!date.isEmpty() && !subject.isEmpty() && !duration.isEmpty()) {
                            String entry = "Date: " + date +
                            ", Subject: " + subject +
                            ", Duration: " + duration + " mins";
                            studyData.add(entry);
                            //TO SAVE IN TXT 
                            try 
                            (FileWriter fw = new FileWriter("StudyData/progress.txt", true)) { 
                                fw.write(entry + System.lineSeparator());
                            } catch (IOException ex) {
                                JOptionPane.showMessageDialog(trackerframe,
                                    "Error saving progress:\n" + ex.getMessage(),
                                    "File Error", JOptionPane.ERROR_MESSAGE);
                            }
                            DisplayArea.setText("Saved!");
                            //CLEAR FIELDS
                            DateField.setText("");
                            SubjectField.setText("");
                            DurationField.setText("");
                        } else {
                            DisplayArea.setText("Please fill all fields.");
                        }
                    }
                });
                //SHOW BUTTON
                ImageIcon icons = new ImageIcon("src/main/resources/images/show.png");
                Image imgs = icons.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
                ImageIcon iconss = new ImageIcon(imgs);
                JButton ShowButton = new JButton("Show",iconss);
                ShowButton.setBounds(400, 320, 150, 30); 
                ShowButton.setFont(new Font("Arial", Font.BOLD, 12)); 
                ShowButton.setFocusable(false);
                ShowButton.setBorderPainted(false);
                //SHOW BUTTON ACTION LISTENER
                ShowButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        DisplayArea.setText(String.join("\n", studyData));
                    }
                });
                //BACK BUTTON
                ImageIcon iconB = new ImageIcon("src/main/resources/images/back.png");
                Image imgB = iconB.getImage().getScaledInstance(23, 23, Image.SCALE_SMOOTH);
                ImageIcon iconBB = new ImageIcon(imgB);
                JButton BackButton = new JButton("Back",iconBB);
                BackButton.setBounds(600, 700, 160, 40);
                BackButton.setFont(new Font("Arial", Font.BOLD, 16)); 
                BackButton.setFocusable(false);
                BackButton.setBorderPainted(false);
                //BACK BUTTON ACTION LISTENER
                BackButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        mainframe.setVisible(true); 
                        trackerframe.dispose();      
                    }
                });
                trackerframe.add(LABEL1);
                trackerframe.add(LABEL2);
                trackerframe.add(DateLabel);
                trackerframe.add(SubjectLabel);
                trackerframe.add(DurationLabel);  
                trackerframe.add(DateField);  
                trackerframe.add(SubjectField);
                trackerframe.add(DurationField);
                trackerframe.add(SaveButton);
                trackerframe.add(ShowButton);
                trackerframe.add(DisplayArea);    
                trackerframe.add(BackButton);    
                trackerframe.setVisible(true);
                mainframe.setVisible(false);
            }
        });
///////////////////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        //TO-DO LIST 
        btnTodo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFrame todoframe = new JFrame("To-Do List"); 
                todoframe.setSize(800, 800); 
                todoframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
                todoframe.setLayout(null); 
                todoframe.setLocationRelativeTo(null);
                //TODO FRAME BACKGROUND 
                ImageIcon bgImage = new ImageIcon("src/main/resources/images/frame.JPG");
                JLabel background = new JLabel() { 
                    public void paintComponent(Graphics g) {
                        g.drawImage(bgImage.getImage(), 0, 0, getWidth(), getHeight(), this);
                    }
                };
                background.setBounds(0, 0, 800, 800); 
                background.setLayout(null);
                todoframe.setContentPane(background);
                //TODO TEXT
                JLabel LABEL1 = new JLabel("To-Do List");
                LABEL1.setFont(new Font("Segoe UI", Font.BOLD, 35));
                LABEL1.setForeground(new Color(30, 30, 60));
                LABEL1.setBounds(292, 40, 300, 50); 
                JLabel LABEL2 = new JLabel("To-Do List");
                LABEL2.setFont(new Font("Segoe UI", Font.BOLD, 35));
                LABEL2.setForeground(Color.LIGHT_GRAY);  
                LABEL2.setBounds(289, 38, 300, 50); 
                //Task Label
                JLabel TaskLabel = new JLabel("Enter your daily tasks here:");
                TaskLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
                TaskLabel.setBounds(50, 150, 350, 25);
                //TextField
                JTextField Field = new JTextField();
                Field.setBounds(50, 192, 700, 30); 
                //ADD BUTTON
                ImageIcon iconA = new ImageIcon("src/main/resources/images/add.png");
                Image imgA = iconA.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
                ImageIcon iconAA = new ImageIcon(imgA);
                JButton AddButton = new JButton("Add Task",iconAA);
                AddButton.setBounds(50, 250, 120, 30);
                AddButton.setFont(new Font("Arial", Font.BOLD, 12)); 
                AddButton.setFocusable(false);
                AddButton.setBorderPainted(false);
                //Delete Button
                ImageIcon iconD = new ImageIcon("src/main/resources/images/remove.png");
                Image imgD = iconD.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
                ImageIcon iconDD = new ImageIcon(imgD);
                JButton DeleteButton = new JButton("Delete",iconDD);
                DeleteButton.setBounds(190, 250, 120, 30); 
                DeleteButton.setFont(new Font("Arial", Font.BOLD, 12)); 
                DeleteButton.setFocusable(false);
                DeleteButton.setBorderPainted(false);
                //Complete Button
                ImageIcon iconC = new ImageIcon("src/main/resources/images/complete.png");
                Image imgC = iconC.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
                ImageIcon iconCC = new ImageIcon(imgC);
                JButton CompleteButton = new JButton("Complete",iconCC);
                CompleteButton.setBounds(330, 250, 120, 30);
                CompleteButton.setFont(new Font("Arial", Font.BOLD, 12)); 
                CompleteButton.setFocusable(false);
                CompleteButton.setBorderPainted(false);
                //LIST MODEL
                DefaultListModel<String> List_data = new DefaultListModel<>();
                JList myList = new JList(List_data);
                JScrollPane scroll = new JScrollPane(myList);
                scroll.setBounds(45, 310, 700, 300); 
                //ADD BUTTON ACTION LISTENER
                AddButton.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        String task = Field.getText();
                        List_data.addElement(task);
                        Field.setText("");
                        try (FileWriter writer = new FileWriter("StudyData/todo.txt")) {
                            for (int i = 0; i < List_data.size(); i++) {
                                writer.write(List_data.getElementAt(i) + "\n");
                            }
                        } catch (IOException ex) {
                            JOptionPane.showMessageDialog(todoframe, "Error saving to-do list.");
                        }
                    }
                });
                //DELETE BUTTON ACTION LISTENER
                DeleteButton.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        int index = myList.getSelectedIndex();
                        if (index != -1) {
                            List_data.remove(index);
                        } 
                        else {
                            javax.swing.JOptionPane.showMessageDialog(todoframe,"No item selected.");
                        }
                    }
                });
                //COMPLETE BUTTON ACTION LISTENER
                CompleteButton.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        int index = myList.getSelectedIndex();
                        if (index != -1) {
                            String task = List_data.getElementAt(index);
                            String completedTask = task + " (completed)";
    
                            List_data.set(index, completedTask); // Update the task in the list
                        } else {
                            JOptionPane.showMessageDialog(todoframe, "No item selected.");
                        }   
                    } 
                });
                //BACK BUTTON
                ImageIcon iconB = new ImageIcon("src/main/resources/images/back.png");
                Image imgB = iconB.getImage().getScaledInstance(23, 23, Image.SCALE_SMOOTH);
                ImageIcon iconBB = new ImageIcon(imgB);
                JButton BackButton = new JButton("Back",iconBB);
                BackButton.setBounds(600, 700, 160, 40); 
                BackButton.setFont(new Font("Arial", Font.BOLD, 16)); 
                BackButton.setFocusable(false);
                BackButton.setBorderPainted(false);
                //BACK BUTTON ACTION LISTENER
                BackButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        mainframe.setVisible(true); 
                        todoframe.dispose();      
                    }
                });
                todoframe.add(LABEL1);
                todoframe.add(LABEL2);
                todoframe.add(TaskLabel);
                todoframe.add(AddButton);
                todoframe.add(DeleteButton);
                todoframe.add(CompleteButton);
                todoframe.add(Field);
                todoframe.add(scroll);
                todoframe.add(BackButton);
                todoframe.setVisible(true);
                mainframe.setVisible(false);
            }
        });
///////////////////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\      
        //EXPORT BUTTON ACTION LISTENER  
        btnExport.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    FileWriter writer = new FileWriter("StudyData/summary_export.txt");
                    // Notes
                    writer.write("===== NOTES =====\n");
                    copy("note.txt", writer);
                    // Planner
                    writer.write("\n===== PLANNER =====\n");
                    copy("planner.txt", writer);
                    // To-Do
                    writer.write("\n===== TO-DO LIST =====\n");
                    copy("todo.txt", writer);
                    // Progress
                    writer.write("\n===== PROGRESS =====\n");
                    copy("progress.txt", writer);
                    writer.close();
                    JOptionPane.showMessageDialog(mainframe, "Export Successful!");
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(mainframe, "Export failed.");
                }
            }
            private void copy(String filename, FileWriter writer) throws IOException {
                try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        writer.write(line + "\n");
                    }
                } catch (IOException e) {
                    writer.write("[No data found in " + filename + "]\n");
                }
            }
        });
///////////////////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        //LOAD DATA BUTTON ACTION LISTENER
        btnLoad.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String content = "";
                content += "===== NOTES =====\n" + readFile("StudyData/notes.txt");
                content += "\n===== PLANNER =====\n" + readFile("StudyData/planner.txt");
                content += "\n===== TO-DO LIST =====\n" + readFile("StudyData/todo.txt");
                content 
                += "\n===== PROGRESS =====\n" + readFile("StudyData/progress.txt");
                JTextArea textArea = new JTextArea(content);
                textArea.setEditable(false);
                textArea.setFont(new Font("Arial", Font.PLAIN, 14));
                JScrollPane scrollPane = new JScrollPane(textArea);
                scrollPane.setPreferredSize(new Dimension(700, 500));
                JOptionPane.showMessageDialog(mainframe, scrollPane, "Loaded Data", JOptionPane.INFORMATION_MESSAGE);
            }
            private String readFile(String filename) {
                StringBuilder result = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        result.append(line).append("\n");
                    }
                } catch (IOException e) {
                    result.append("[File not found]\n");
                }
                return result.toString();
            }
        });
///////////////////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        //EXIT BUTTON
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int choice = JOptionPane.showConfirmDialog(
                    mainframe,
                    "Are you sure you want to quit?",
                    "Exit Confirmation",
                    JOptionPane.YES_NO_OPTION,
     
                    JOptionPane.WARNING_MESSAGE);

                if (choice == JOptionPane.YES_OPTION) System.exit(0);
            }
        });
///////////////////////////////////////////////////////////THE END\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ 
        
        
        
    }
}